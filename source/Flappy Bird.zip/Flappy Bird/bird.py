import pygame

class Bird(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("img/bird.png").convert_alpha()
        self.startX = x
        self.startY = y
        self.rect = self.image.get_rect(center=(45 // 2, 15))
        self.rect.x = x
        self.rect.y = y
        self.yval = 0
        self.jump = False
        self.force = -10
        self.game = True
        self.fall = False

    def update(self):

        self.checkGameOver()

        if self.game:
            keys = pygame.key.get_pressed()

            if keys[pygame.K_SPACE] and self.yval > -5:
                self.yval = self.force

            self.yval += 0.5

            self.rect.y += self.yval

    def checkGameOver(self):
        if self.game:
            if (self.rect.y <= 0) or (self.rect.y >= 600 - 32):
                self.game = False
        else:
            self.gameOver()

    def gameOver(self):
        if self.rect.y <= 600 - 32:

            self.yval = 5
            self.rect.y += self.yval

        else:
            self.fall = True

        if self.fall:
            keys = pygame.key.get_pressed()

            if keys[pygame.K_SPACE]:
                self.rect.x = self.startX
                self.rect.y = self.startY
                self.game = True
                self.fall = False

    def checkCollision(self, blockDown, blockUp):
        if self.game:
            if pygame.sprite.collide_rect(self, blockDown):
                self.game = False
                self.gameOver()
            elif pygame.sprite.collide_rect(self, blockUp):
                self.game = False
                self.gameOver()