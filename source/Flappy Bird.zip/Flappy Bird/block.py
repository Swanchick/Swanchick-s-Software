import pygame
import random

class BlockDown(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.image.load("img/pump1.png")
        self.rect = self.image.get_rect()
        self.rect.x = 600
        self.rect.y = 300

    def update(self):
        if self.rect.x >= -32 * 2:
            self.rect.x -= 5
        else:
            self.rect.x = 600
            self.rect.y = random.randint(200, 550)


class BlockUp(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.image.load("img/pump2.png")
        self.rect = self.image.get_rect()
        self.rect.x = 600
        self.rect.y = 300 - 600

    def update(self, posY):
        if self.rect.x >= -32 * 2:
            self.rect.x -= 5
        else:
            self.rect.x = 600
            self.rect.y = posY - 600