import pygame
from bird import Bird
from block import BlockDown, BlockUp
from platform import Platform1, Platform2

pygame.init()

display = pygame.display.set_mode((600, 800))

pygame.display.set_caption("Flappy Bird")

sprite_group = pygame.sprite.Group()

clock = pygame.time.Clock()
jump = False

bird = Bird(100, 500)
blockDown = BlockDown()
blockUp = BlockUp()

platform1, platform2 = Platform1(), Platform2()

sprite_group.add(blockDown)
sprite_group.add(blockUp)

sprite_group.add(platform1)
sprite_group.add(platform2)

sprite_group.add(bird)

screen = pygame.Surface((600, 800))

bg = pygame.image.load("img/backround.png").convert()

def run():
    global jump
    game = True

    while game:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game = False

        display.fill((0, 0, 0))
        display.blit(screen, (0, 0))


        screen.blit(bg, (0, 0))

        bird.update()
        bird.checkCollision(blockDown, blockUp)

        if bird.game:
            blockDown.update()
            blockUp.update(blockDown.rect.y)
            platform1.move()
            platform2.move()
        else:
            blockUp.rect.x = 600
            blockDown.rect.x = 600

        sprite_group.draw(display)

        pygame.display.update()

        clock.tick(60)

    pygame.quit()

if __name__ == '__main__':
    run()