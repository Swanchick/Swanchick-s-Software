import pygame

class Platform1(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.image.load("img/platform.png")
        self.rect = self.image.get_rect()
        self.rect.x = 0
        self.rect.y = 600

    def move(self):
        if self.rect.x != -600:
            self.rect.x -= 5
        else:
            self.rect.x = 600

class Platform2(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.image.load("img/platform.png")
        self.rect = self.image.get_rect()
        self.rect.x = 600
        self.rect.y = 600

    def move(self):
        if self.rect.x != -600:
            self.rect.x -= 5
        else:
            self.rect.x = 600