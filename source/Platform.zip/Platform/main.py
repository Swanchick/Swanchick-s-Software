import pygame
from player import Player
from platform import Platform
from spikes import Spikes

width, height = 1280, 720
fps = 60

tile = 100

pygame.init()

display = pygame.display.set_mode((width, height))

level = [
    "-                                         -",
    "-                                         -",
    "-                                         -",
    "-                                         -",
    "-             -------                     -",
    "-            ---                          -",
    "-      p    ----^^^^^^^^^^^^^^^^^^^^^^^^^^-",
    "-------------------------------------------",
]

screen = pygame.Surface((len(level[0]) * tile, len(level) * tile))

sprite_group = pygame.sprite.Group()

platforms = []

spikes = []


for row in range(len(level)):
    line = level[row]
    for col in range(len(line)):
        x = col * tile
        y = row * tile
        if line[col] == '-':
            pl = Platform(x, y)
            sprite_group.add(pl)
            platforms.append(pl)
        elif line[col] == 'p':
            player = Player(x, y)
            sprite_group.add(player)
        elif line[col] == '^':
            sp = Spikes(x, y)
            sprite_group.add(sp)
            spikes.append(sp)

screen_x = 0
screen_y = 0

clock = pygame.time.Clock()

def run():
    global screen_x
    game = True
    while game:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game = False


        display.fill((0, 0, 0))
        display.blit(screen, (screen_x, screen_y))
        screen.fill((50, 190, 255))

        player.update(platforms, spikes)
        sprite_group.draw(screen)
        screen_x = -player.rect.x + width / 2

        pygame.display.update()
        clock.tick(fps)

    pygame.quit()


if __name__ == '__main__':
    run()