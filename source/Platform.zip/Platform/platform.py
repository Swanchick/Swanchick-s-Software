from pygame.sprite import Sprite
from pygame.image import load
from pygame import Surface

class Platform(Sprite):
    def __init__(self, x, y):
        Sprite.__init__(self)
        self.image = Surface((100, 100))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y