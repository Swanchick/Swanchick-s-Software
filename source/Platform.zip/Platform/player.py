import pygame

GRAVITY = 0.4

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((32, 32))
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect()
        self.startX = x
        self.startY = y
        self.rect.x = x
        self.rect.y = y
        self.xvel = 0
        self.yvel = 0
        self.speed = 7
        self.onGround = False
        self.jumpForce = 10

    def controller(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_RIGHT]:
            self.xvel = self.speed

        if keys[pygame.K_LEFT]:
            self.xvel = -self.speed

        if not (keys[pygame.K_RIGHT] or keys[pygame.K_LEFT]):
            self.xvel = 0

        if not self.onGround:
            self.yvel += GRAVITY

        if keys[pygame.K_SPACE] and self.onGround:
            self.yvel = -self.jumpForce

    def update(self, platforms, spikes):
        self.controller()

        self.onGround = False

        self.rect.x += self.xvel
        self.collide(platforms, self.xvel, 0, spikes)
        self.rect.y += self.yvel
        self.collide(platforms, 0, self.yvel, spikes)

    def draw(self, surf):
        surf.blit(self.image, (self.rect.x, self.rect.y))

    def collide(self, platforms, xvel, yvel, spikes):
        for pl in platforms:
            if pygame.sprite.collide_rect(self, pl):
                if xvel > 0:
                    self.rect.right = pl.rect.left

                if xvel < 0:
                    self.rect.left = pl.rect.right

                if yvel > 0:
                    self.rect.bottom = pl.rect.top
                    self.onGround = True
                    self.yvel = 0

                if yvel < 0:
                    self.rect.top = pl.rect.bottom
                    self.yvel = 0
        for sp in spikes:
            if pygame.sprite.collide_rect(self, sp):
                self.rect.x = self.startX
                self.rect.y = self.startY