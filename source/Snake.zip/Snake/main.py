import pygame
import random

# Settings

WIDTH = 800
HEIGHT = 800
HALF_WIDTH = WIDTH // 2
HALF_HEIGHT = HEIGHT // 2
TILE = 25
FPS = 10

# Colors

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (150, 0, 0)
GREEN = (0, 150, 0)
BLUE = (0, 0, 150)
GRAY = (25, 25, 25)

pygame.init()

pygame.display.set_caption("Snake")

display = pygame.display.set_mode((WIDTH, HEIGHT))

clock = pygame.time.Clock()

snake_pos = (16 * TILE, 16 * TILE)
apple_pos = (random.randint(1, WIDTH // TILE), random.randint(1, HEIGHT // TILE))

def draw_web(display):
    for i in range(HEIGHT // TILE):
        for j in range(WIDTH // TILE):
            x, y = j * TILE, i * TILE
            pygame.draw.rect(display, GRAY, (x, y, TILE, TILE), 2)

def draw_text(message, x, y, display, size):
    font = pygame.font.SysFont("Arial", size)
    text = font.render(str(message), True, WHITE)
    display.blit(text, (x, y))

class Snake:
    def __init__(self, pos, display):
        self.x = pos[0]
        self.y = pos[1]
        self.pos = [(self.x, self.y)]
        self.display = display
        self.velocity = "right"
        self.speed = 25
        self.length = 1
        self.game = True

    def draw(self):
        for i, j in self.pos:
            pygame.draw.rect(self.display, GREEN, (i, j, TILE, TILE))

    def move(self):
        if self.game:
            if self.velocity == "left":
                self.x -= self.speed

            elif self.velocity == "right":
                self.x += self.speed

            elif self.velocity == "up":
                self.y -= self.speed

            elif self.velocity == "down":
                self.y += self.speed

            self.pos.append((self.x, self.y))

            self.pos = self.pos[-self.length:]

    def controller(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT] and self.velocity != "right":
            self.velocity = "left"
        if keys[pygame.K_RIGHT] and self.velocity != "left":
            self.velocity = "right"
        if keys[pygame.K_UP] and self.velocity != "down":
            self.velocity = "up"
        if keys[pygame.K_DOWN] and self.velocity != "up":
            self.velocity = "down"

    def game_over(self):
        if self.game:
            if self.x < 0 or self.y < 0 or  self.x > WIDTH - TILE or self.y > HEIGHT - TILE:
                self.game = False

            if len(self.pos) != len(set(self.pos)):
                self.game = False
        else:
            draw_text("Game Over", WIDTH // 2 - 200, HEIGHT // 2 - 100, display, 100)

            keys = pygame.key.get_pressed()

            if keys[pygame.K_SPACE]:
                self.x, self.y = 16 * TILE, 16 * TILE
                self.velocity = "right"
                self.length = 1
                self.pos = [(self.x, self.y)]
                apple.random()
                self.game = True

    def score(self, apple_pos):
        if self.x == apple_pos[0] and self.y == apple_pos[1]:
            self.length += 1
            apple.random()

class Apple:
    def __init__(self, pos, display):
        self.x = pos[0] * TILE
        self.y = pos[1] * TILE
        self.display = display

    def draw(self):
        pygame.draw.rect(self.display, RED, (self.x, self.y, TILE, TILE))

    @property
    def position(self):
        return (self.x, self.y)

    def random(self):
        ran_x, ran_y = random.randint(1, WIDTH // TILE - 1), random.randint(1, HEIGHT // TILE - 1)
        self.x = ran_x * TILE
        self.y = ran_y * TILE


snake = Snake(snake_pos, display)
apple = Apple(apple_pos, display)

def run():
    loop = True
    while loop:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                loop = False

        display.fill(BLACK)

        # draw_web(display)

        apple.draw()

        snake.draw()
        snake.controller()
        snake.move()
        snake.game_over()
        snake.score(apple.position)

        draw_text(f"Score: {snake.length - 1}", 0, 0, display, 50)

        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()

if __name__ == '__main__':
    run()